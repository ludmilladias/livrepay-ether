import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Zap, QrCode, Copy, Share, Clock } from "lucide-react"
import { useState } from "react"

const Pix = () => {
  const [dialogOpen, setDialogOpen] = useState(false)
  const pixCobrancas = [
    {
      id: "1",
      descricao: "Pagamento Consultoria - Cliente ABC",
      valor: "R$ 3.500,00",
      vencimento: "28/02/2024",
      status: "Aguardando",
      tipo: "QR Code",
      criado: "15/01/2024",
      txid: "abc123def456"
    },
    {
      id: "2",
      descricao: "Venda Produto Digital - E-commerce",
      valor: "R$ 199,00",
      vencimento: "25/02/2024",
      status: "Pago",
      tipo: "PIX Copia e Cola",
      criado: "12/01/2024",
      txid: "def789ghi012"
    },
    {
      id: "3",
      descricao: "Assinatura Mensal - SaaS Platform",
      valor: "R$ 497,00",
      vencimento: "20/02/2024",
      status: "Expirado",
      tipo: "QR Code",
      criado: "08/01/2024",
      txid: "ghi345jkl678"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pago": return "bg-green-100 text-green-800"
      case "Expirado": return "bg-red-100 text-red-800"
      case "Aguardando": return "bg-yellow-100 text-yellow-800"
      case "Cancelado": return "bg-gray-100 text-gray-800"
      default: return "bg-blue-100 text-blue-800"
    }
  }

  const getTipoIcon = (tipo: string) => {
    return tipo === "QR Code" ? QrCode : Copy
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">PIX Cobrança</h1>
          <p className="text-muted-foreground mt-2">
            Crie cobranças PIX instantâneas com QR Code ou Copia e Cola
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Cobrança PIX
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Nova Cobrança PIX</DialogTitle>
              <DialogDescription>
                Crie uma cobrança PIX instantânea
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Input id="descricao" placeholder="Ex: Pagamento Consultoria Janeiro" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="valor">Valor (R$)</Label>
                  <Input id="valor" type="number" placeholder="0,00" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="vencimento">Vencimento</Label>
                  <Input id="vencimento" type="date" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="tipo">Tipo de PIX</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="qrcode">QR Code</SelectItem>
                    <SelectItem value="copiacola">PIX Copia e Cola</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea id="observacoes" placeholder="Informações adicionais sobre o pagamento" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={() => setDialogOpen(false)}>
                Criar PIX
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Cobranças</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">89</div>
            <p className="text-xs text-muted-foreground">
              +15 este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagos</CardTitle>
            <Zap className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">76</div>
            <p className="text-xs text-muted-foreground">
              Taxa: 85.4%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tempo Médio</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2m 15s</div>
            <p className="text-xs text-muted-foreground">
              Para confirmação
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 98.750</div>
            <p className="text-xs text-muted-foreground">
              +34% vs mês anterior
            </p>
          </CardContent>
        </Card>
      </div>

      {/* PIX Table */}
      <Card>
        <CardHeader>
          <CardTitle>Cobranças PIX</CardTitle>
          <CardDescription>
            Gerencie suas cobranças PIX e acompanhe o status em tempo real
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Descrição</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Vencimento</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>TXID</TableHead>
                <TableHead>Criado em</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pixCobrancas.map((pix) => {
                const TipoIcon = getTipoIcon(pix.tipo)
                return (
                  <TableRow key={pix.id}>
                    <TableCell className="font-medium">{pix.descricao}</TableCell>
                    <TableCell className="font-semibold text-green-600">{pix.valor}</TableCell>
                    <TableCell>{pix.vencimento}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <TipoIcon className="h-4 w-4" />
                        <span className="text-sm">{pix.tipo}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(pix.status)} variant="secondary">
                        {pix.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{pix.txid}</TableCell>
                    <TableCell className="text-muted-foreground">{pix.criado}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="sm">
                          <QrCode className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Share className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

export default Pix