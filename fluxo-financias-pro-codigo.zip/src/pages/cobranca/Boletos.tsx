import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Plus, FileText, Download, Eye, RefreshCw } from "lucide-react"
import { useState } from "react"

const Boletos = () => {
  const [dialogOpen, setDialogOpen] = useState(false)
  const boletos = [
    {
      id: "1",
      numero: "00190.12345 12345.678901 23456.789012 1 89600000012500",
      cliente: "João Silva Santos",
      valor: "R$ 1.250,00",
      vencimento: "25/02/2024",
      status: "Aguardando",
      emissao: "15/01/2024"
    },
    {
      id: "2",
      numero: "00190.54321 54321.987654 65432.109876 2 89700000025000",
      cliente: "Maria Oliveira Ltda",
      valor: "R$ 2.500,00", 
      vencimento: "20/02/2024",
      status: "Pago",
      emissao: "10/01/2024"
    },
    {
      id: "3",
      numero: "00190.98765 98765.456789 78901.234567 3 89800000050000",
      cliente: "Tech Solutions Inc",
      valor: "R$ 5.000,00",
      vencimento: "10/02/2024",
      status: "Vencido",
      emissao: "05/01/2024"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pago": return "bg-green-100 text-green-800"
      case "Vencido": return "bg-red-100 text-red-800"
      case "Aguardando": return "bg-yellow-100 text-yellow-800"
      case "Cancelado": return "bg-gray-100 text-gray-800"
      default: return "bg-blue-100 text-blue-800"
    }
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Boletos</h1>
          <p className="text-muted-foreground mt-2">
            Emita e gerencie boletos bancários
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Emitir Boleto
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Emitir Boleto</DialogTitle>
              <DialogDescription>
                Emita um boleto bancário para cobrança
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="cliente">Nome do Cliente</Label>
                <Input id="cliente" placeholder="Nome completo ou razão social" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="cpf">CPF/CNPJ</Label>
                  <Input id="cpf" placeholder="000.000.000-00" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="valor">Valor (R$)</Label>
                  <Input id="valor" type="number" placeholder="0,00" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="vencimento">Data de Vencimento</Label>
                <Input id="vencimento" type="date" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="instrucoes">Instruções</Label>
                <Textarea id="instrucoes" placeholder="Instruções para o pagamento" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={() => setDialogOpen(false)}>
                Emitir Boleto
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Emitidos</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">156</div>
            <p className="text-xs text-muted-foreground">
              +12 este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pagos</CardTitle>
            <FileText className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">134</div>
            <p className="text-xs text-muted-foreground">
              Taxa: 85.9%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Em Aberto</CardTitle>
            <FileText className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <p className="text-xs text-muted-foreground">
              -3 vs semana anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 187.450</div>
            <p className="text-xs text-muted-foreground">
              +22% vs mês anterior
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Boletos Table */}
      <Card>
        <CardHeader>
          <CardTitle>Boletos Emitidos</CardTitle>
          <CardDescription>
            Visualize e gerencie todos os boletos emitidos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Linha Digitável</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Vencimento</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Emitido em</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {boletos.map((boleto) => (
                <TableRow key={boleto.id}>
                  <TableCell className="font-mono text-xs">
                    {boleto.numero.substring(0, 47)}...
                  </TableCell>
                  <TableCell className="font-medium">{boleto.cliente}</TableCell>
                  <TableCell className="font-semibold text-green-600">{boleto.valor}</TableCell>
                  <TableCell>{boleto.vencimento}</TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(boleto.status)} variant="secondary">
                      {boleto.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{boleto.emissao}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                      {boleto.status === "Aguardando" && (
                        <Button variant="ghost" size="sm">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

export default Boletos