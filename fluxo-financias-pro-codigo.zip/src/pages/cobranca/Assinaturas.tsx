import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, RefreshCw, Users, CreditCard, Pause, Play } from "lucide-react"
import { useState } from "react"

const Assinaturas = () => {
  const [dialogOpen, setDialogOpen] = useState(false)
  const assinaturas = [
    {
      id: "1",
      cliente: "Tech Solutions LTDA",
      plano: "Enterprise",
      valor: "R$ 2.500,00",
      periodo: "Mensal",
      proximoVencimento: "15/03/2024",
      status: "Ativa",
      inicioContrato: "15/01/2023",
      metodoPagamento: "Cartão de Crédito"
    },
    {
      id: "2",
      cliente: "João Silva",
      plano: "Professional",
      valor: "R$ 497,00",
      periodo: "Mensal",
      proximoVencimento: "20/03/2024",
      status: "Pausada",
      inicioContrato: "20/06/2023",
      metodoPagamento: "PIX"
    },
    {
      id: "3",
      cliente: "Maria Oliveira MEI",
      plano: "Starter",
      valor: "R$ 97,00",
      periodo: "Mensal",
      proximoVencimento: "25/03/2024",
      status: "Pendente",
      inicioContrato: "25/11/2023",
      metodoPagamento: "Boleto"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Ativa": return "bg-green-100 text-green-800"
      case "Pausada": return "bg-yellow-100 text-yellow-800"
      case "Pendente": return "bg-red-100 text-red-800"
      case "Cancelada": return "bg-gray-100 text-gray-800"
      default: return "bg-blue-100 text-blue-800"
    }
  }

  const getMetodoIcon = (metodo: string) => {
    switch (metodo) {
      case "Cartão de Crédito": return CreditCard
      case "PIX": return RefreshCw
      default: return Users
    }
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Assinaturas</h1>
          <p className="text-muted-foreground mt-2">
            Gerencie assinaturas e cobranças recorrentes
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nova Assinatura
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Nova Assinatura</DialogTitle>
              <DialogDescription>
                Crie uma assinatura recorrente para seu cliente
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="cliente">Nome do Cliente</Label>
                <Input id="cliente" placeholder="Nome completo ou razão social" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="plano">Plano</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o plano" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="starter">Starter - R$ 97</SelectItem>
                      <SelectItem value="professional">Professional - R$ 497</SelectItem>
                      <SelectItem value="enterprise">Enterprise - R$ 2.500</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="periodo">Período</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Periodicidade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mensal">Mensal</SelectItem>
                      <SelectItem value="trimestral">Trimestral</SelectItem>
                      <SelectItem value="semestral">Semestral</SelectItem>
                      <SelectItem value="anual">Anual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="valor">Valor (R$)</Label>
                  <Input id="valor" type="number" placeholder="0,00" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="vencimento">Primeiro Vencimento</Label>
                  <Input id="vencimento" type="date" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="metodo">Método de Pagamento</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Como será cobrado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cartao">Cartão de Crédito</SelectItem>
                    <SelectItem value="pix">PIX</SelectItem>
                    <SelectItem value="boleto">Boleto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={() => setDialogOpen(false)}>
                Criar Assinatura
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Assinaturas Ativas</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42</div>
            <p className="text-xs text-muted-foreground">
              +7 este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">MRR</CardTitle>
            <RefreshCw className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 28.450</div>
            <p className="text-xs text-muted-foreground">
              +12% vs mês anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Churn</CardTitle>
            <Users className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3.2%</div>
            <p className="text-xs text-muted-foreground">
              -1.1% vs mês anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Médio</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 677</div>
            <p className="text-xs text-muted-foreground">
              +8% vs mês anterior
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Assinaturas Table */}
      <Card>
        <CardHeader>
          <CardTitle>Assinaturas Ativas</CardTitle>
          <CardDescription>
            Acompanhe todas as assinaturas e seus respectivos status
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Plano</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Período</TableHead>
                <TableHead>Próximo Venc.</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Método</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assinaturas.map((assinatura) => {
                const MetodoIcon = getMetodoIcon(assinatura.metodoPagamento)
                return (
                  <TableRow key={assinatura.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{assinatura.cliente}</div>
                        <div className="text-sm text-muted-foreground">
                          Desde {assinatura.inicioContrato}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{assinatura.plano}</TableCell>
                    <TableCell className="font-semibold text-green-600">
                      {assinatura.valor}/{assinatura.periodo.toLowerCase()}
                    </TableCell>
                    <TableCell>{assinatura.periodo}</TableCell>
                    <TableCell>{assinatura.proximoVencimento}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(assinatura.status)} variant="secondary">
                        {assinatura.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <MetodoIcon className="h-4 w-4" />
                        <span className="text-sm">{assinatura.metodoPagamento}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {assinatura.status === "Ativa" ? (
                          <Button variant="ghost" size="sm">
                            <Pause className="h-4 w-4" />
                          </Button>
                        ) : (
                          <Button variant="ghost" size="sm">
                            <Play className="h-4 w-4" />
                          </Button>
                        )}
                        <Button variant="ghost" size="sm">
                          <CreditCard className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

export default Assinaturas