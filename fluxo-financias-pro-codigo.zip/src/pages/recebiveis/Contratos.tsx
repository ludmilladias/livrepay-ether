import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, FileText, Download, Eye, Calendar, DollarSign } from "lucide-react"

const Contratos = () => {
  const contratos = [
    {
      id: "1",
      numero: "CTR-2024-001",
      cliente: "Tech Solutions LTDA",
      tipo: "Antecipação de Recebíveis",
      valor: "R$ 85.000,00",
      taxa: "2.5%",
      prazo: "60 dias",
      dataInicio: "15/01/2024",
      dataVencimento: "15/03/2024",
      status: "Ativo",
      valorPago: "R$ 65.000,00"
    },
    {
      id: "2",
      numero: "CTR-2024-002", 
      cliente: "João Silva MEI",
      tipo: "Linha de Crédito",
      valor: "R$ 25.000,00",
      taxa: "3.2%",
      prazo: "90 dias",
      dataInicio: "20/01/2024",
      dataVencimento: "20/04/2024",
      status: "Ativo",
      valorPago: "R$ 15.000,00"
    },
    {
      id: "3",
      numero: "CTR-2023-089",
      cliente: "Maria Consultoria",
      tipo: "Antecipação de Recebíveis",
      valor: "R$ 45.000,00",
      taxa: "2.8%",
      prazo: "45 dias",
      dataInicio: "15/12/2023",
      dataVencimento: "30/01/2024",
      status: "Concluído",
      valorPago: "R$ 45.000,00"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Ativo": return "bg-green-100 text-green-800"
      case "Concluído": return "bg-blue-100 text-blue-800"
      case "Em Atraso": return "bg-red-100 text-red-800"
      case "Suspenso": return "bg-yellow-100 text-yellow-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case "Antecipação de Recebíveis": return "text-green-600"
      case "Linha de Crédito": return "text-blue-600"
      case "Financiamento": return "text-purple-600"
      default: return "text-gray-600"
    }
  }

  const calcularProgresso = (valorPago: string, valorTotal: string) => {
    const pago = parseFloat(valorPago.replace(/[^\d,]/g, '').replace(',', '.'))
    const total = parseFloat(valorTotal.replace(/[^\d,]/g, '').replace(',', '.'))
    return (pago / total) * 100
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Contratos</h1>
          <p className="text-muted-foreground mt-2">
            Gerencie todos os seus contratos de antecipação e financiamento
          </p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Novo Contrato
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Contratos Ativos</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">
              +2 este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 887.500</div>
            <p className="text-xs text-muted-foreground">
              Contratos ativos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa Média</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2.8%</div>
            <p className="text-xs text-muted-foreground">
              a.m. contratos ativos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Concluídos</CardTitle>
            <Calendar className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">45</div>
            <p className="text-xs text-muted-foreground">
              Este ano
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Contratos Table */}
      <Card>
        <CardHeader>
          <CardTitle>Seus Contratos</CardTitle>
          <CardDescription>
            Visualize e gerencie todos os seus contratos e acompanhe o progresso
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nº Contrato</TableHead>
                <TableHead>Cliente/Tipo</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Taxa</TableHead>
                <TableHead>Vigência</TableHead>
                <TableHead>Progresso</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contratos.map((contrato) => {
                const progresso = calcularProgresso(contrato.valorPago, contrato.valor)
                return (
                  <TableRow key={contrato.id}>
                    <TableCell>
                      <div className="font-medium font-mono">{contrato.numero}</div>
                      <div className="text-sm text-muted-foreground">{contrato.cliente}</div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{contrato.cliente}</div>
                      <div className={`text-sm ${getTipoColor(contrato.tipo)}`}>
                        {contrato.tipo}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-semibold text-green-600">{contrato.valor}</div>
                      <div className="text-sm text-muted-foreground">
                        Pago: {contrato.valorPago}
                      </div>
                    </TableCell>
                    <TableCell>{contrato.taxa} a.m.</TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>Início: {contrato.dataInicio}</div>
                        <div>Venc: {contrato.dataVencimento}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full" 
                          style={{ width: `${progresso}%` }}
                        ></div>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {progresso.toFixed(0)}% concluído
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(contrato.status)} variant="secondary">
                        {contrato.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Calendar className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Resumo de Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Performance dos Contratos</CardTitle>
            <CardDescription>
              Análise de performance dos últimos 12 meses
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium">Taxa de Adimplência:</span>
                <span className="font-bold text-green-600">97.2%</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="text-sm font-medium">Tempo Médio de Quitação:</span>
                <span className="font-bold text-blue-600">52 dias</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span className="text-sm font-medium">Valor Médio dos Contratos:</span>
                <span className="font-bold text-purple-600">R$ 73.950</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Próximos Vencimentos</CardTitle>
            <CardDescription>
              Contratos com vencimento nos próximos 30 dias
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <div className="font-medium">CTR-2024-001</div>
                  <div className="text-sm text-muted-foreground">Tech Solutions</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">15/03/2024</div>
                  <div className="text-sm text-green-600">R$ 20.000 restante</div>
                </div>
              </div>
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <div className="font-medium">CTR-2024-002</div>
                  <div className="text-sm text-muted-foreground">João Silva</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">20/04/2024</div>
                  <div className="text-sm text-green-600">R$ 10.000 restante</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Contratos