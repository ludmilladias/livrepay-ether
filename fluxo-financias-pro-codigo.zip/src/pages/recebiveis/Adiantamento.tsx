import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, TrendingUp, Clock, CheckCircle, XCircle } from "lucide-react"

const Adiantamento = () => {
  const adiantamentos = [
    {
      id: "1",
      protocolo: "ADT-2024-001",
      valor: "R$ 25.000,00",
      valorSolicitado: "R$ 30.000,00",
      taxa: "2.8%",
      prazo: "45 dias",
      status: "Aprovado",
      datasolicitacao: "10/02/2024",
      dataLiberacao: "12/02/2024"
    },
    {
      id: "2", 
      protocolo: "ADT-2024-002",
      valor: "R$ 15.500,00",
      valorSolicitado: "R$ 18.000,00",
      taxa: "3.2%",
      prazo: "60 dias",
      status: "Em Análise",
      datasolicitacao: "15/02/2024",
      dataLiberacao: "-"
    },
    {
      id: "3",
      protocolo: "ADT-2024-003",
      valor: "-",
      valorSolicitado: "R$ 12.000,00",
      taxa: "-",
      prazo: "30 dias",
      status: "Negado",
      datasolicitacao: "18/02/2024",
      dataLiberacao: "-"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Aprovado": return "bg-green-100 text-green-800"
      case "Em Análise": return "bg-yellow-100 text-yellow-800"
      case "Negado": return "bg-red-100 text-red-800"
      case "Liberado": return "bg-blue-100 text-blue-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Aprovado": return CheckCircle
      case "Em Análise": return Clock
      case "Negado": return XCircle
      case "Liberado": return TrendingUp
      default: return Clock
    }
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Adiantamento de Recebíveis</h1>
          <p className="text-muted-foreground mt-2">
            Solicite adiantamento dos seus recebíveis e melhore seu fluxo de caixa
          </p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Solicitar Adiantamento
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Solicitado</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 450.000</div>
            <p className="text-xs text-muted-foreground">
              Este ano
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aprovado</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 387.500</div>
            <p className="text-xs text-muted-foreground">
              86.1% de aprovação
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Em Análise</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 32.500</div>
            <p className="text-xs text-muted-foreground">
              Aguardando aprovação
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa Média</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2.9%</div>
            <p className="text-xs text-muted-foreground">
              a.m. últimas operações
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Processo de Adiantamento */}
      <Card>
        <CardHeader>
          <CardTitle>Como Funciona o Adiantamento</CardTitle>
          <CardDescription>
            Entenda o processo completo do adiantamento de recebíveis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">1</span>
              </div>
              <h4 className="font-medium mb-2">Solicitação</h4>
              <p className="text-sm text-muted-foreground">
                Envie sua solicitação com os recebíveis que deseja antecipar
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">2</span>
              </div>
              <h4 className="font-medium mb-2">Análise</h4>
              <p className="text-sm text-muted-foreground">
                Nossa equipe analisa sua solicitação em até 24 horas
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">3</span>
              </div>
              <h4 className="font-medium mb-2">Aprovação</h4>
              <p className="text-sm text-muted-foreground">
                Você recebe a proposta com taxa e condições
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">4</span>
              </div>
              <h4 className="font-medium mb-2">Liberação</h4>
              <p className="text-sm text-muted-foreground">
                O valor é creditado em sua conta em até 1 dia útil
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Histórico de Adiantamentos */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Solicitações</CardTitle>
          <CardDescription>
            Acompanhe todas as suas solicitações de adiantamento
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Protocolo</TableHead>
                <TableHead>Valor Solicitado</TableHead>
                <TableHead>Valor Aprovado</TableHead>
                <TableHead>Taxa</TableHead>
                <TableHead>Prazo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Solicitado em</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {adiantamentos.map((adiantamento) => {
                const StatusIcon = getStatusIcon(adiantamento.status)
                return (
                  <TableRow key={adiantamento.id}>
                    <TableCell className="font-medium font-mono">
                      {adiantamento.protocolo}
                    </TableCell>
                    <TableCell>{adiantamento.valorSolicitado}</TableCell>
                    <TableCell className="font-semibold text-green-600">
                      {adiantamento.valor}
                    </TableCell>
                    <TableCell>{adiantamento.taxa}</TableCell>
                    <TableCell>{adiantamento.prazo}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <StatusIcon className="h-4 w-4" />
                        <Badge className={getStatusColor(adiantamento.status)} variant="secondary">
                          {adiantamento.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {adiantamento.datasolicitacao}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        Ver Detalhes
                      </Button>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Documentos Necessários */}
      <Card>
        <CardHeader>
          <CardTitle>Documentos Necessários</CardTitle>
          <CardDescription>
            Prepare estes documentos para agilizar sua solicitação
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-3">Pessoa Jurídica:</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• CNPJ atualizado</li>
                <li>• Contrato social ou estatuto</li>
                <li>• Comprovante de faturamento</li>
                <li>• Extratos bancários (3 meses)</li>
                <li>• Demonstrativo de recebíveis</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-3">Pessoa Física:</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• CPF e RG atualizados</li>
                <li>• Comprovante de residência</li>
                <li>• Comprovante de renda</li>
                <li>• Extratos bancários (3 meses)</li>
                <li>• Demonstrativo de recebíveis</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Adiantamento