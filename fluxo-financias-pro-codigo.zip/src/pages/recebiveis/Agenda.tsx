import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Calendar, Filter, TrendingUp, Clock, DollarSign } from "lucide-react"

const Agenda = () => {
  const recebiveis = [
    {
      id: "1",
      descricao: "Pagamento Cliente ABC - Consultoria",
      valor: "R$ 5.500,00",
      dataVencimento: "15/03/2024",
      status: "Confirmado",
      tipo: "PIX",
      cliente: "ABC Consultoria Ltda",
      origem: "Link de Pagamento"
    },
    {
      id: "2",
      descricao: "Boleto - Serviços Janeiro",
      valor: "R$ 2.800,00",
      dataVencimento: "20/03/2024",
      status: "Pendente",
      tipo: "Boleto",
      cliente: "Tech Solutions",
      origem: "Boleto Bancário"
    },
    {
      id: "3",
      descricao: "Assinatura Mensal - SaaS",
      valor: "R$ 497,00",
      dataVencimento: "25/03/2024",
      status: "Confirmado",
      tipo: "Cartão",
      cliente: "João Silva",
      origem: "Assinatura Recorrente"
    },
    {
      id: "4",
      descricao: "Produto Digital - E-book",
      valor: "R$ 197,00",
      dataVencimento: "28/03/2024",
      status: "Atrasado",
      tipo: "PIX",
      cliente: "Maria Santos",
      origem: "Loja Virtual"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Confirmado": return "bg-green-100 text-green-800"
      case "Pendente": return "bg-yellow-100 text-yellow-800"
      case "Atrasado": return "bg-red-100 text-red-800"
      case "Cancelado": return "bg-gray-100 text-gray-800"
      default: return "bg-blue-100 text-blue-800"
    }
  }

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case "PIX": return "text-green-600"
      case "Boleto": return "text-blue-600"
      case "Cartão": return "text-purple-600"
      default: return "text-gray-600"
    }
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Agenda de Recebíveis</h1>
          <p className="text-muted-foreground mt-2">
            Acompanhe seus recebimentos futuros e organize seu fluxo de caixa
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filtros
          </Button>
          <Button variant="outline" className="gap-2">
            <Calendar className="h-4 w-4" />
            Período
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total a Receber</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 127.450</div>
            <p className="text-xs text-muted-foreground">
              Nos próximos 30 dias
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Confirmados</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 98.750</div>
            <p className="text-xs text-muted-foreground">
              77.5% do total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 23.450</div>
            <p className="text-xs text-muted-foreground">
              18.4% do total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Em Atraso</CardTitle>
            <Clock className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 5.250</div>
            <p className="text-xs text-muted-foreground">
              4.1% do total
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Agenda Table */}
      <Card>
        <CardHeader>
          <CardTitle>Próximos Recebimentos</CardTitle>
          <CardDescription>
            Visualize todos os recebimentos programados organizados por data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Descrição</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Origem</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recebiveis.map((recebivel) => (
                <TableRow key={recebivel.id}>
                  <TableCell>
                    <div className="font-medium">{recebivel.descricao}</div>
                  </TableCell>
                  <TableCell className="font-medium">{recebivel.cliente}</TableCell>
                  <TableCell className="font-semibold text-green-600">{recebivel.valor}</TableCell>
                  <TableCell>{recebivel.dataVencimento}</TableCell>
                  <TableCell>
                    <span className={`font-medium ${getTipoColor(recebivel.tipo)}`}>
                      {recebivel.tipo}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(recebivel.status)} variant="secondary">
                      {recebivel.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{recebivel.origem}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="sm">
                        <Calendar className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <TrendingUp className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Calendar View Card */}
      <Card>
        <CardHeader>
          <CardTitle>Visão por Calendário</CardTitle>
          <CardDescription>
            Visualize seus recebimentos em um calendário mensal
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64 border-2 border-dashed border-muted-foreground/25 rounded-lg">
            <div className="text-center">
              <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Calendário de recebimentos</p>
              <p className="text-sm text-muted-foreground mt-1">Em desenvolvimento</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Agenda