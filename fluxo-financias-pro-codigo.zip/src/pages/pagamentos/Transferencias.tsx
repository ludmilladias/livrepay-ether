import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Plus, Send, Clock, CheckCircle, XCircle, ArrowRightLeft } from "lucide-react"

const Transferencias = () => {
  const transferencias = [
    {
      id: "1",
      destinatario: "João Silva Santos",
      banco: "Banco do Brasil",
      agencia: "1234-5",
      conta: "67890-1",
      valor: "R$ 5.500,00",
      tipo: "TED",
      data: "20/02/2024",
      status: "Concluída",
      comprovante: "TED-001-2024"
    },
    {
      id: "2",
      destinatario: "Tech Solutions LTDA",
      banco: "Itaú Unibanco",
      agencia: "2468-9",
      conta: "13579-2",
      valor: "R$ 12.800,00",
      tipo: "PIX",
      data: "19/02/2024",
      status: "Processando",
      comprovante: "PIX-002-2024"
    },
    {
      id: "3",
      destinatario: "Maria Consultoria MEI",
      banco: "Nubank",
      agencia: "0001",
      conta: "24681-3",
      valor: "R$ 2.300,00",
      tipo: "PIX",
      data: "18/02/2024",
      status: "Falhou",
      comprovante: "-"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Concluída": return "bg-green-100 text-green-800"
      case "Processando": return "bg-yellow-100 text-yellow-800"
      case "Falhou": return "bg-red-100 text-red-800"
      case "Agendada": return "bg-blue-100 text-blue-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Concluída": return CheckCircle
      case "Processando": return Clock
      case "Falhou": return XCircle
      case "Agendada": return Clock
      default: return Clock
    }
  }

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case "PIX": return "text-green-600"
      case "TED": return "text-blue-600"
      case "DOC": return "text-purple-600"
      default: return "text-gray-600"
    }
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Transferências</h1>
          <p className="text-muted-foreground mt-2">
            Realize transferências PIX, TED e DOC de forma rápida e segura
          </p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Nova Transferência
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Transferido</CardTitle>
            <ArrowRightLeft className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 287.450</div>
            <p className="text-xs text-muted-foreground">
              Este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Transferências</CardTitle>
            <Send className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">89</div>
            <p className="text-xs text-muted-foreground">
              +15 vs mês anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Sucesso</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">98.9%</div>
            <p className="text-xs text-muted-foreground">
              Últimos 30 dias
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Economia</CardTitle>
            <ArrowRightLeft className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 2.850</div>
            <p className="text-xs text-muted-foreground">
              Em taxas este mês
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Nova Transferência */}
      <Card>
        <CardHeader>
          <CardTitle>Nova Transferência</CardTitle>
          <CardDescription>
            Preencha os dados para realizar uma nova transferência
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="destinatario">Nome do Destinatário</Label>
                <Input id="destinatario" placeholder="Nome completo ou razão social" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="documento">CPF/CNPJ</Label>
                <Input id="documento" placeholder="000.000.000-00" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="banco">Banco</Label>
                <Input id="banco" placeholder="Nome ou código do banco" />
              </div>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="agencia">Agência</Label>
                  <Input id="agencia" placeholder="0000" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="conta">Conta</Label>
                  <Input id="conta" placeholder="00000-0" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="valor">Valor</Label>
                <Input id="valor" placeholder="R$ 0,00" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição (opcional)</Label>
                <Input id="descricao" placeholder="Motivo da transferência" />
              </div>
            </div>
          </div>
          <div className="flex gap-4 mt-6">
            <Button className="gap-2">
              <Send className="h-4 w-4" />
              Transferir via PIX
            </Button>
            <Button variant="outline" className="gap-2">
              <Send className="h-4 w-4" />
              Transferir via TED
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Histórico */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Transferências</CardTitle>
          <CardDescription>
            Acompanhe todas as suas transferências realizadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Destinatário</TableHead>
                <TableHead>Banco/Conta</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Comprovante</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transferencias.map((transferencia) => {
                const StatusIcon = getStatusIcon(transferencia.status)
                return (
                  <TableRow key={transferencia.id}>
                    <TableCell className="font-medium">{transferencia.destinatario}</TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{transferencia.banco}</div>
                        <div className="text-muted-foreground">
                          {transferencia.agencia} / {transferencia.conta}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-semibold text-green-600">{transferencia.valor}</TableCell>
                    <TableCell>
                      <span className={`font-medium ${getTipoColor(transferencia.tipo)}`}>
                        {transferencia.tipo}
                      </span>
                    </TableCell>
                    <TableCell>{transferencia.data}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <StatusIcon className="h-4 w-4" />
                        <Badge className={getStatusColor(transferencia.status)} variant="secondary">
                          {transferencia.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {transferencia.comprovante}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        Ver Detalhes
                      </Button>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

export default Transferencias