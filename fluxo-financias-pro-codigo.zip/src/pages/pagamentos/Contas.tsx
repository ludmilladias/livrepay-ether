import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, FileText, Calendar, DollarSign, Building, Zap } from "lucide-react"

const Contas = () => {
  const contas = [
    {
      id: "1",
      tipo: "Energia Elétrica",
      empresa: "CEMIG",
      codigo: "123456789",
      valor: "R$ 485,90",
      vencimento: "25/03/2024",
      status: "Pendente",
      categoria: "Utilidades",
      numeroFatura: "EE-2024-001"
    },
    {
      id: "2",
      tipo: "IPTU",
      empresa: "Prefeitura Municipal",
      codigo: "987654321",
      valor: "R$ 1.250,00",
      vencimento: "15/03/2024",
      status: "Pago",
      categoria: "Tributos",
      numeroFatura: "TR-2024-002"
    },
    {
      id: "3",
      tipo: "Telefone",
      empresa: "Vivo",
      codigo: "456789123",
      valor: "R$ 89,90",
      vencimento: "10/03/2024",
      status: "Atrasado",
      categoria: "Telecomunicações",
      numeroFatura: "TC-2024-003"
    },
    {
      id: "4",
      tipo: "ISS",
      empresa: "Receita Federal",
      codigo: "789123456",
      valor: "R$ 890,00",
      vencimento: "20/03/2024",
      status: "Agendado",
      categoria: "Tributos",
      numeroFatura: "TR-2024-004"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pago": return "bg-green-100 text-green-800"
      case "Pendente": return "bg-yellow-100 text-yellow-800"
      case "Atrasado": return "bg-red-100 text-red-800"
      case "Agendado": return "bg-blue-100 text-blue-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  const getCategoriaColor = (categoria: string) => {
    switch (categoria) {
      case "Tributos": return "text-red-600"
      case "Utilidades": return "text-blue-600"
      case "Telecomunicações": return "text-purple-600"
      case "Financeiro": return "text-green-600"
      default: return "text-gray-600"
    }
  }

  const getCategoriaIcon = (categoria: string) => {
    switch (categoria) {
      case "Tributos": return Building
      case "Utilidades": return Zap
      case "Telecomunicações": return FileText
      default: return FileText
    }
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Contas e Tributos</h1>
          <p className="text-muted-foreground mt-2">
            Pague suas contas e tributos de forma centralizada e organizada
          </p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Adicionar Conta
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total a Pagar</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 12.850</div>
            <p className="text-xs text-muted-foreground">
              Este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Contas Pagas</CardTitle>
            <FileText className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">28</div>
            <p className="text-xs text-muted-foreground">
              De 35 contas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Em Atraso</CardTitle>
            <Calendar className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">
              R$ 1.240 em multas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Economia</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 450</div>
            <p className="text-xs text-muted-foreground">
              Em descontos este mês
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Calendário de Vencimentos */}
      <Card>
        <CardHeader>
          <CardTitle>Próximos Vencimentos</CardTitle>
          <CardDescription>
            Organize seus pagamentos pelos próximos vencimentos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-l-4 border-l-red-500">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Hoje - 25/03</span>
                    <Badge className="bg-red-100 text-red-800" variant="secondary">2 contas</Badge>
                  </div>
                  <div className="text-lg font-bold text-red-600">R$ 1.735,90</div>
                  <p className="text-sm text-muted-foreground">CEMIG + Internet</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-yellow-500">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Esta Semana</span>
                    <Badge className="bg-yellow-100 text-yellow-800" variant="secondary">5 contas</Badge>
                  </div>
                  <div className="text-lg font-bold text-yellow-600">R$ 3.420,50</div>
                  <p className="text-sm text-muted-foreground">Água, gás e outros</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-blue-500">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Próximo Mês</span>
                    <Badge className="bg-blue-100 text-blue-800" variant="secondary">12 contas</Badge>
                  </div>
                  <div className="text-lg font-bold text-blue-600">R$ 7.694,60</div>
                  <p className="text-sm text-muted-foreground">Tributos e serviços</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Contas */}
      <Card>
        <CardHeader>
          <CardTitle>Suas Contas e Tributos</CardTitle>
          <CardDescription>
            Gerencie todas as suas contas e tributos em um só lugar
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tipo/Empresa</TableHead>
                <TableHead>Código</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Vencimento</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Fatura</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contas.map((conta) => {
                const CategoriaIcon = getCategoriaIcon(conta.categoria)
                return (
                  <TableRow key={conta.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{conta.tipo}</div>
                        <div className="text-sm text-muted-foreground">{conta.empresa}</div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm">{conta.codigo}</TableCell>
                    <TableCell className="font-semibold text-green-600">{conta.valor}</TableCell>
                    <TableCell>{conta.vencimento}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <CategoriaIcon className="h-4 w-4" />
                        <span className={`text-sm ${getCategoriaColor(conta.categoria)}`}>
                          {conta.categoria}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(conta.status)} variant="secondary">
                        {conta.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{conta.numeroFatura}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="sm">
                          Ver Fatura
                        </Button>
                        {conta.status !== "Pago" && (
                          <Button size="sm">
                            Pagar
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Categorias de Gastos */}
      <Card>
        <CardHeader>
          <CardTitle>Gastos por Categoria</CardTitle>
          <CardDescription>
            Análise dos seus gastos organizados por categoria
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Building className="h-8 w-8 text-red-600" />
                  <div>
                    <div className="text-sm text-muted-foreground">Tributos</div>
                    <div className="text-lg font-bold">R$ 4.850</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Zap className="h-8 w-8 text-blue-600" />
                  <div>
                    <div className="text-sm text-muted-foreground">Utilidades</div>
                    <div className="text-lg font-bold">R$ 3.240</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <FileText className="h-8 w-8 text-purple-600" />
                  <div>
                    <div className="text-sm text-muted-foreground">Telecom</div>
                    <div className="text-lg font-bold">R$ 1.890</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="h-8 w-8 text-green-600" />
                  <div>
                    <div className="text-sm text-muted-foreground">Outros</div>
                    <div className="text-lg font-bold">R$ 2.870</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Contas