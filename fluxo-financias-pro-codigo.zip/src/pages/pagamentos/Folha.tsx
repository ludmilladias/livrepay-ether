import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Users, FileSpreadsheet, Calendar, DollarSign, Download, Upload } from "lucide-react"

const Folha = () => {
  const lotesPagamento = [
    {
      id: "1",
      nome: "Folha Março 2024",
      tipo: "Salários",
      funcionarios: 25,
      valorTotal: "R$ 87.500,00",
      dataProcessamento: "25/03/2024",
      status: "Processado",
      arquivoOrigem: "folha_marco_2024.xlsx"
    },
    {
      id: "2",
      nome: "13º Salário - 1ª Parcela",
      tipo: "Benefícios",
      funcionarios: 25,
      valorTotal: "R$ 43.750,00",
      dataProcessamento: "30/11/2023",
      status: "Concluído",
      arquivoOrigem: "13_salario_2023.xlsx"
    },
    {
      id: "3",
      nome: "Comissões Fevereiro",
      tipo: "Comissões",
      funcionarios: 8,
      valorTotal: "R$ 12.480,00",
      dataProcessamento: "05/03/2024",
      status: "Agendado",
      arquivoOrigem: "comissoes_fev_2024.xlsx"
    },
    {
      id: "4",
      nome: "Vale Alimentação",
      tipo: "Benefícios",
      funcionarios: 25,
      valorTotal: "R$ 15.000,00",
      dataProcessamento: "01/03/2024",
      status: "Erro",
      arquivoOrigem: "vale_alimentacao_mar.xlsx"
    }
  ]

  const funcionarios = [
    {
      id: "1",
      nome: "João Silva Santos",
      cargo: "Desenvolvedor Senior",
      departamento: "TI",
      salarioBase: "R$ 8.500,00",
      banco: "Itaú",
      agencia: "1234",
      conta: "56789-0",
      status: "Ativo"
    },
    {
      id: "2",
      nome: "Maria Oliveira",
      cargo: "Gerente de Marketing",
      departamento: "Marketing",
      salarioBase: "R$ 12.000,00",
      banco: "Bradesco",
      agencia: "5678",
      conta: "98765-4",
      status: "Ativo"
    },
    {
      id: "3",
      nome: "Pedro Costa",
      cargo: "Analista Financeiro",
      departamento: "Financeiro",
      salarioBase: "R$ 6.500,00",
      banco: "Banco do Brasil",
      agencia: "9012",
      conta: "34567-8",
      status: "Férias"
    }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Concluído": return "bg-green-100 text-green-800"
      case "Processado": return "bg-blue-100 text-blue-800"
      case "Agendado": return "bg-yellow-100 text-yellow-800"
      case "Erro": return "bg-red-100 text-red-800"
      case "Ativo": return "bg-green-100 text-green-800"
      case "Férias": return "bg-blue-100 text-blue-800"
      case "Afastado": return "bg-yellow-100 text-yellow-800"
      default: return "bg-gray-100 text-gray-800"
    }
  }

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case "Salários": return "text-green-600"
      case "Benefícios": return "text-blue-600"
      case "Comissões": return "text-purple-600"
      case "Férias": return "text-orange-600"
      default: return "text-gray-600"
    }
  }

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Folha de Pagamento & Lotes</h1>
          <p className="text-muted-foreground mt-2">
            Gerencie a folha de pagamento e processe lotes de pagamentos em massa
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Upload className="h-4 w-4" />
            Importar Planilha
          </Button>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Novo Lote
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Funcionários Ativos</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">25</div>
            <p className="text-xs text-muted-foreground">
              +2 este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Folha Mensal</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ 187.500</div>
            <p className="text-xs text-muted-foreground">
              +5% vs mês anterior
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lotes Processados</CardTitle>
            <FileSpreadsheet className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">
              Este mês
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Sucesso</CardTitle>
            <Calendar className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">98.5%</div>
            <p className="text-xs text-muted-foreground">
              Últimos 30 dias
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Lotes de Pagamento */}
      <Card>
        <CardHeader>
          <CardTitle>Lotes de Pagamento</CardTitle>
          <CardDescription>
            Histórico e status dos lotes de pagamentos processados
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome do Lote</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Funcionários</TableHead>
                <TableHead>Valor Total</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Arquivo</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lotesPagamento.map((lote) => (
                <TableRow key={lote.id}>
                  <TableCell className="font-medium">{lote.nome}</TableCell>
                  <TableCell>
                    <span className={`font-medium ${getTipoColor(lote.tipo)}`}>
                      {lote.tipo}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">{lote.funcionarios}</TableCell>
                  <TableCell className="font-semibold text-green-600">{lote.valorTotal}</TableCell>
                  <TableCell>{lote.dataProcessamento}</TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(lote.status)} variant="secondary">
                      {lote.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{lote.arquivoOrigem}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        Ver Detalhes
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Cadastro de Funcionários */}
      <Card>
        <CardHeader>
          <CardTitle>Funcionários Cadastrados</CardTitle>
          <CardDescription>
            Gerencie os dados bancários dos funcionários para a folha de pagamento
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Cargo</TableHead>
                <TableHead>Departamento</TableHead>
                <TableHead>Salário Base</TableHead>
                <TableHead>Dados Bancários</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {funcionarios.map((funcionario) => (
                <TableRow key={funcionario.id}>
                  <TableCell className="font-medium">{funcionario.nome}</TableCell>
                  <TableCell>{funcionario.cargo}</TableCell>
                  <TableCell>{funcionario.departamento}</TableCell>
                  <TableCell className="font-semibold text-green-600">{funcionario.salarioBase}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{funcionario.banco}</div>
                      <div className="text-muted-foreground">
                        {funcionario.agencia} / {funcionario.conta}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(funcionario.status)} variant="secondary">
                      {funcionario.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      Editar
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Instruções de Upload */}
      <Card>
        <CardHeader>
          <CardTitle>Como Importar Planilha</CardTitle>
          <CardDescription>
            Siga estas instruções para importar sua planilha de folha de pagamento
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-3">Formato da Planilha:</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Formato: .xlsx ou .csv</li>
                <li>• Primeira linha deve conter os cabeçalhos</li>
                <li>• Codificação: UTF-8</li>
                <li>• Máximo: 1000 funcionários por arquivo</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-3">Campos Obrigatórios:</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• Nome completo</li>
                <li>• CPF (apenas números)</li>
                <li>• Valor a pagar</li>
                <li>• Banco, agência e conta</li>
                <li>• Tipo de conta (corrente/poupança)</li>
              </ul>
            </div>
          </div>
          <div className="mt-6">
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Baixar Modelo de Planilha
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Folha