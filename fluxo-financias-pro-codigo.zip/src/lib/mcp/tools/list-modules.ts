import { defineTool } from "@lovable.dev/mcp-js";
import { modules } from "../data";

export default defineTool({
  name: "list_modules",
  title: "List app modules",
  description: "List the app's modules (Cobrança, Recebíveis, Pagamentos, Seguros, Cartões & Wallet, Relatórios) and the routes of their pages.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => ({
    content: [{ type: "text", text: JSON.stringify(modules, null, 2) }],
    structuredContent: { modules },
  }),
});