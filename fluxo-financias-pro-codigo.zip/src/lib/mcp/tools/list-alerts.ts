import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { alerts } from "../data";

export default defineTool({
  name: "list_alerts",
  title: "List operational alerts",
  description: "List the demo operational alerts shown on the dashboard, optionally filtered by type (urgent, warning, info, success).",
  inputSchema: {
    type: z
      .enum(["urgent", "warning", "info", "success"])
      .optional()
      .describe("Only return alerts of this type."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ type }) => {
    const items = type ? alerts.filter((a) => a.type === type) : alerts;
    return {
      content: [{ type: "text", text: JSON.stringify(items, null, 2) }],
      structuredContent: { alerts: items },
    };
  },
});