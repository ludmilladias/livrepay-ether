import { defineTool } from "@lovable.dev/mcp-js";
import { nextActions } from "../data";

export default defineTool({
  name: "list_next_actions",
  title: "List next actions",
  description: "List the demo pending next actions with their deadlines and priority.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => ({
    content: [{ type: "text", text: JSON.stringify(nextActions, null, 2) }],
    structuredContent: { nextActions },
  }),
});