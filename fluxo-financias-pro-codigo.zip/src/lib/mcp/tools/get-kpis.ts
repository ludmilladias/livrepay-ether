import { defineTool } from "@lovable.dev/mcp-js";
import { kpis } from "../data";

export default defineTool({
  name: "get_kpis",
  title: "Get financial KPIs",
  description: "Return the demo dashboard KPIs (saldo total, caixa D0, caixa D+30, limite disponível, taxa de fraude) with their variation versus the previous period.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => ({
    content: [{ type: "text", text: JSON.stringify(kpis, null, 2) }],
    structuredContent: { kpis },
  }),
});