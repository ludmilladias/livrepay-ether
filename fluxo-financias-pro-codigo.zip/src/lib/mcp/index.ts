import { auth, defineMcp } from "@lovable.dev/mcp-js";
import getKpisTool from "./tools/get-kpis";
import listAlertsTool from "./tools/list-alerts";
import listNextActionsTool from "./tools/list-next-actions";
import listModulesTool from "./tools/list-modules";

const projectRef = import.meta.env.VITE_SUPABASE_PROJECT_ID ?? "project-ref-unset";

export default defineMcp({
  name: "fluxo-financias-pro",
  title: "fluxo-financias-pro",
  version: "0.1.0",
  instructions:
    "Read-only tools for the fluxo-financias-pro financial operations dashboard (demo data). Use `get_kpis` for balances and cash-flow KPIs, `list_alerts` for operational alerts, `list_next_actions` for pending tasks, and `list_modules` to discover the app's modules and page routes.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [getKpisTool, listAlertsTool, listNextActionsTool, listModulesTool],
});