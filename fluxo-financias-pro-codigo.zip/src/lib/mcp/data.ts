// Demo data exposed by the public MCP server. Import-safe: no env reads, no I/O.
export const kpis = [
  { id: "saldo_total", title: "Saldo Total", value: 4184204.35, change: "+12.5%", description: "vs. mês anterior" },
  { id: "caixa_d0", title: "Caixa D0", value: 847291.75, change: "+8.2%", description: "disponível hoje" },
  { id: "caixa_d30", title: "Caixa D+30", value: 2156842.6, change: "-2.1%", description: "próximos 30 dias" },
  { id: "limite_disponivel", title: "Limite Disponível", value: 500000, change: "75%", description: "do limite total" },
  { id: "risco_fraude", title: "Risco/Fraude", value: 0.0002, change: "-0.01%", description: "taxa de fraude" },
] as const;

export const alerts = [
  { id: 1, type: "urgent", title: "Tentativa de fraude bloqueada", description: "PIX de R$ 15.000 foi bloqueado automaticamente por suspeita de fraude", time: "2 min atrás" },
  { id: 2, type: "warning", title: "KYC pendente", description: "3 clientes aguardam verificação de documentos", time: "15 min atrás" },
  { id: 3, type: "info", title: "Boletos vencendo hoje", description: "12 boletos vencem nas próximas 2 horas", time: "1 hora atrás" },
  { id: 4, type: "success", title: "Liquidação concluída", description: "R$ 45.280,00 liquidados automaticamente", time: "2 horas atrás" },
] as const;

export const nextActions = [
  { title: "Aprovar folha de pagamento", description: "Lote de 150 funcionários - R$ 284.750,00", deadline: "Hoje, 17:00", priority: "high" },
  { title: "Renovar apólice de seguro", description: "Seguro empresarial vence em 5 dias", deadline: "23 Jan", priority: "medium" },
  { title: "Revisar limites de PIX", description: "Ajuste semanal de limites por cliente", deadline: "Amanhã", priority: "low" },
] as const;

export const modules = [
  { title: "Cobrança", pages: [
    { title: "Links de Pagamento", path: "/cobranca/links" },
    { title: "Boletos", path: "/cobranca/boletos" },
    { title: "PIX Cobrança", path: "/cobranca/pix" },
    { title: "Assinaturas", path: "/cobranca/assinaturas" },
  ] },
  { title: "Recebíveis", pages: [
    { title: "Agenda", path: "/recebiveis/agenda" },
    { title: "Simulador", path: "/recebiveis/simulador" },
    { title: "Adiantamento", path: "/recebiveis/adiantamento" },
    { title: "Contratos", path: "/recebiveis/contratos" },
  ] },
  { title: "Pagamentos", pages: [
    { title: "Transferências", path: "/pagamentos/transferencias" },
    { title: "Contas e Tributos", path: "/pagamentos/contas" },
    { title: "Folha/Lotes", path: "/pagamentos/folha" },
  ] },
  { title: "Seguros", pages: [
    { title: "Catálogo", path: "/seguros/catalogo" },
    { title: "Cotações", path: "/seguros/cotacoes" },
    { title: "Apólices", path: "/seguros/apolices" },
    { title: "Sinistros", path: "/seguros/sinistros" },
  ] },
  { title: "Cartões & Wallet", pages: [
    { title: "Cartões Virtuais", path: "/cartoes/virtuais" },
    { title: "Limites", path: "/cartoes/limites" },
    { title: "Extratos", path: "/cartoes/extratos" },
  ] },
  { title: "Relatórios", pages: [
    { title: "Extratos", path: "/relatorios/extratos" },
    { title: "Conciliação", path: "/relatorios/conciliacao" },
    { title: "Financeiro", path: "/relatorios/financeiro" },
  ] },
] as const;